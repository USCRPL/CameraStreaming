#ifndef AES
#define AES

//#include "driver.h"
//#include "device.h"
//#include "stdafx.h"
//#include <windows.h>

typedef unsigned char Byte;

//for 128bit
#define Nb 4
#define Nk 4
#define Nr 10



/*
void MixColumns(byte State[4][4]);
void InvMixColumns(byte State[4][4]);
void SubBytes(byte State[4][4]);
void InvSubBytes(byte State[4][4]);
void ShiftRows(byte State[4][4]);
void InvShiftRows(byte State[4][4]);
void KeyExpansion(byte key[]);
*/

void Cipher(Byte* input);  // encipher 16-byte input
void InvCipher(Byte* input);  // decipher 16-byte input
void KeyExpansion(Byte* encrypt_key);
#endif