#pragma once
#include "stdafx.h"
#include "aes.h"
#include <string.h>


namespace AES128_dec {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	unsigned char key[16] =
			{
				0x0F, 0x15, 0x71, 0xC9, 0x47, 0xD9, 0xE8, 0x59,
				0x0C, 0xB7, 0xAD, 0xD6, 0xAF, 0x7F, 0x67, 0x98
			};

	


	/// <summary>
	/// Form1 ���K�n
	///
	/// ĵ�i: �p�G�z�ܧ�o�����O���W�١A�N�����ܧ�P�o�����O�Ҩ̾ڤ��Ҧ� .resx �ɮ����p��
	///          Managed �귽�sĶ���u�㪺 'Resource File Name' �ݩʡC
	///          �_�h�A�o�ǳ]�p�u��
	///          �N�L�k�P�o�Ӫ������p�����a�y�t�Ƹ귽
	///          ���T���ʡC
	/// </summary>
	
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		
		Form1(void)
		{
			int i;
			InitializeComponent();
			
			this->key_dec_value = gcnew array<NumericUpDown^>(16);
			this->label = gcnew array<Label^>(16);
			for(i = 0; i < 16; i++)
			{
				this->key_dec_value[i] = gcnew NumericUpDown();	
				this->Controls->Add(key_dec_value[i]);
				this->label[i] = gcnew Label();	
				this->Controls->Add(label[i]);
			}
			for(i = 0; i < 16; i++)
				{	
				    this->key_dec_value[i] = (gcnew System::Windows::Forms::NumericUpDown());
					(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->key_dec_value[i]))->BeginInit();
					this->groupBox2->Controls->Add(this->key_dec_value[i]);
					this->key_dec_value[i]->Location = System::Drawing::Point(15+43*i, 55);
					this->key_dec_value[i]->Size = System::Drawing::Size(37, 22);
					this->key_dec_value[i]->Enabled= false;
					this->key_dec_value[i]->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
					this->key_dec_value[i]->Font = (gcnew System::Drawing::Font(L"PMingLiU", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(136)));
					this->key_dec_value[i]->TabIndex = i;
					(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->key_dec_value[i]))->EndInit();
				}
			for(i = 0; i < 16; i++)
			{
				this->key_dec_value[i]->Text =key[i].ToString() ;
				this->key_dec_value[i]->Hexadecimal = true;

			}

			this->label[0] = (gcnew System::Windows::Forms::Label());
			this->groupBox2->Controls->Add(this->label[0]);
			this->label[0]->AutoSize = true;
			this->label[0]->Location = System::Drawing::Point(15+43*0, 42);
			this->label[0]->Size = System::Drawing::Size(20, 12);
			this->label[0]->Text ="MSB";

			this->label[1] = (gcnew System::Windows::Forms::Label());
			this->groupBox2->Controls->Add(this->label[1]);
			this->label[1]->AutoSize = true;
			this->label[1]->Location = System::Drawing::Point(15+43*15, 42);
			this->label[1]->Size = System::Drawing::Size(20, 12);
			this->label[1]->Text ="LSB";


			
			//
			//TODO: �b���[�J�غc�禡�{���X
			//
		}

	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

//	private: BinaryReader^ binReader;
//	private: FileStream^ fs;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
	private: System::Windows::Forms::TabControl^  tabControl1;
	private: System::Windows::Forms::TabPage^  tabPage1;
	private: System::Windows::Forms::Button^  Run_bu;

	private: System::Windows::Forms::Button^  Save_bu;
	private: System::Windows::Forms::Button^  Load_bu;



	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::CheckBox^  par_check;



	private: System::Windows::Forms::CheckBox^  de_code_check;



	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	protected: 

	private:
		array<NumericUpDown^>^ key_dec_value;
		array<Label^>^ label;
	private: System::Windows::Forms::SaveFileDialog^  saveFileDialog1;
	private: System::Windows::Forms::NumericUpDown^  Start_B;






			 /// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边�ק�o�Ӥ�k�����e�C
		///
		/// </summary>
		void InitializeComponent(void)
		{
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->Save_bu = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->Start_B = (gcnew System::Windows::Forms::NumericUpDown());
			this->par_check = (gcnew System::Windows::Forms::CheckBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->de_code_check = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->Load_bu = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->Run_bu = (gcnew System::Windows::Forms::Button());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->menuStrip1->SuspendLayout();
			this->tabControl1->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Start_B))->BeginInit();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->FileName = L"openFileDialog1";
			this->openFileDialog1->Filter = L"bin files|*.ts";
			this->openFileDialog1->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::openFileDialog1_FileOk);
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->aboutToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(744, 24);
			this->menuStrip1->TabIndex = 27;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// aboutToolStripMenuItem
			// 
			this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
			this->aboutToolStripMenuItem->Size = System::Drawing::Size(46, 20);
			this->aboutToolStripMenuItem->Text = L"About";
			this->aboutToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::aboutToolStripMenuItem_Click);
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tabControl1->Location = System::Drawing::Point(0, 24);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(744, 364);
			this->tabControl1->TabIndex = 28;
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->groupBox4);
			this->tabPage1->Controls->Add(this->groupBox3);
			this->tabPage1->Controls->Add(this->groupBox2);
			this->tabPage1->Controls->Add(this->groupBox1);
			this->tabPage1->Controls->Add(this->Run_bu);
			this->tabPage1->Location = System::Drawing::Point(4, 21);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(736, 339);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"Decryption";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->Save_bu);
			this->groupBox4->Controls->Add(this->textBox2);
			this->groupBox4->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox4->Location = System::Drawing::Point(3, 213);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(730, 59);
			this->groupBox4->TabIndex = 57;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"Save the decryption file";
			// 
			// Save_bu
			// 
			this->Save_bu->Enabled = false;
			this->Save_bu->Location = System::Drawing::Point(495, 21);
			this->Save_bu->Name = L"Save_bu";
			this->Save_bu->Size = System::Drawing::Size(75, 23);
			this->Save_bu->TabIndex = 52;
			this->Save_bu->Text = L"Save";
			this->Save_bu->UseVisualStyleBackColor = true;
			this->Save_bu->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(13, 21);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(476, 22);
			this->textBox2->TabIndex = 50;
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->Start_B);
			this->groupBox3->Controls->Add(this->par_check);
			this->groupBox3->Controls->Add(this->label3);
			this->groupBox3->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox3->Location = System::Drawing::Point(3, 155);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(730, 58);
			this->groupBox3->TabIndex = 56;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Partial decryption";
			this->groupBox3->Enter += gcnew System::EventHandler(this, &Form1::groupBox3_Enter);
			// 
			// Start_B
			// 
			this->Start_B->Enabled = false;
			this->Start_B->Location = System::Drawing::Point(224, 15);
			this->Start_B->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1000, 0, 0, 0});
			this->Start_B->Name = L"Start_B";
			this->Start_B->Size = System::Drawing::Size(39, 22);
			this->Start_B->TabIndex = 49;
			this->Start_B->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {4, 0, 0, 0});
			// 
			// par_check
			// 
			this->par_check->AutoSize = true;
			this->par_check->Location = System::Drawing::Point(8, 21);
			this->par_check->Name = L"par_check";
			this->par_check->Size = System::Drawing::Size(144, 16);
			this->par_check->TabIndex = 30;
			this->par_check->Text = L"Enable partial decryption:";
			this->par_check->UseVisualStyleBackColor = true;
			this->par_check->CheckedChanged += gcnew System::EventHandler(this, &Form1::par_check_CheckedChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Times New Roman", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(155, 22);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(63, 15);
			this->label3->TabIndex = 48;
			this->label3->Text = L"Start Byte:";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->de_code_check);
			this->groupBox2->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox2->Location = System::Drawing::Point(3, 64);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(730, 91);
			this->groupBox2->TabIndex = 55;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Input the decryption codes(Hex)";
			// 
			// de_code_check
			// 
			this->de_code_check->AutoSize = true;
			this->de_code_check->Location = System::Drawing::Point(8, 25);
			this->de_code_check->Name = L"de_code_check";
			this->de_code_check->Size = System::Drawing::Size(154, 16);
			this->de_code_check->TabIndex = 29;
			this->de_code_check->Text = L"Change AES128 Key(Hex):";
			this->de_code_check->UseVisualStyleBackColor = true;
			this->de_code_check->CheckedChanged += gcnew System::EventHandler(this, &Form1::de_code_check_CheckedChanged);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->Load_bu);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox1->Location = System::Drawing::Point(3, 3);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(730, 61);
			this->groupBox1->TabIndex = 54;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Load the encryption file";
			// 
			// Load_bu
			// 
			this->Load_bu->Location = System::Drawing::Point(495, 21);
			this->Load_bu->Name = L"Load_bu";
			this->Load_bu->Size = System::Drawing::Size(75, 23);
			this->Load_bu->TabIndex = 51;
			this->Load_bu->Text = L"Load";
			this->Load_bu->UseVisualStyleBackColor = true;
			this->Load_bu->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(13, 21);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(476, 22);
			this->textBox1->TabIndex = 49;
			// 
			// Run_bu
			// 
			this->Run_bu->Enabled = false;
			this->Run_bu->Location = System::Drawing::Point(16, 289);
			this->Run_bu->Name = L"Run_bu";
			this->Run_bu->Size = System::Drawing::Size(75, 23);
			this->Run_bu->TabIndex = 53;
			this->Run_bu->Text = L"Run";
			this->Run_bu->UseVisualStyleBackColor = true;
			this->Run_bu->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// saveFileDialog1
			// 
			this->saveFileDialog1->Filter = L"bin files|*.dec";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(744, 388);
			this->Controls->Add(this->tabControl1);
			this->Controls->Add(this->menuStrip1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MainMenuStrip = this->menuStrip1;
			this->MaximizeBox = false;
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"AES128";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->tabControl1->ResumeLayout(false);
			this->tabPage1->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Start_B))->EndInit();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void openFileDialog1_FileOk(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
			 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void checkBox1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void groupBox3_Enter(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void numericUpDown1_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void aboutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 Windows::Forms::MessageBox::Show("ITE AES128 Decryption Tool version : 1.0\nCopyright (c) ITE Technologies, Inc. 2012", "ITE AES128 Decryption Tool");

		 }

		 
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
		 {			 
			 if(openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)				
			 this->textBox1->Text = openFileDialog1->FileName; // Show path
			 this->saveFileDialog1->FileName=(this->openFileDialog1->FileName)+"_dec";
			 this->Save_bu->Enabled=true;
		
		 }
private: System::Void openFileDialog2_FileOk(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e)
		 {
			 if(saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			 this->textBox2->Text = this->saveFileDialog1->FileName; // Show path
			 this->Run_bu->Enabled=true;

		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			int i;
			unsigned int f_count,f_length;
			unsigned int offset=0;
			unsigned char data[16];
			unsigned char data_par[188];
			
			for (i = 0; i < 16; i++)
				data[i] = i;

			if(this->de_code_check->Checked ==true)
				for (i = 0; i < 16; i++)
					key[i]=Int32(key_dec_value[i]->Value);
			else
			{
				key[0]=0x0F;
				key[1]=0x15;
				key[2]=0x71;
				key[3]=0xC9;
				key[4]=0x47;
				key[5]=0xD9;
				key[6]=0xE8;
				key[7]=0x59;
				key[8]=0x0C;
				key[9]=0xB7;
				key[10]=0xAD;
				key[11]=0xD6;
				key[12]=0xAF;
				key[13]=0x7F;
				key[14]=0x67;
				key[15]=0x98;
			}

	
			KeyExpansion(key);
				
			f_count=0;
			FileStream^ fs = File::Open(openFileDialog1->FileName, FileMode::Open);
			BinaryReader^ binReader = gcnew BinaryReader(fs);
			BinaryWriter^ binWriter = gcnew BinaryWriter((File::Open(saveFileDialog1->FileName, FileMode::Create)));
			f_length=Int32(fs->Length);


			while(1)
				{
				  try
				  {
					if(this->par_check->Checked ==true) //partial decryption
					{
						offset=Int32(Start_B->Value);
						for(i = 0; i < 188; i++)
						{
							data_par[i] = binReader->ReadByte();
							f_count++;
					
							if(f_count==f_length) //The end of file
								break;
					
						}
							InvCipher(data_par+offset);

				     
						if(f_count==f_length)//The remainder of file's bytes
						{
							if(i!=187)
								i++;
							else
							{
								for(i = 0; i < 188; i++)
								binWriter->Write(data_par[i]);
								i=0;
							}
							break;
						}
						for(i = 0; i < 188; i++)
							binWriter->Write(data_par[i]);

					}
					else                         //all decryption
					{

						for(i = 0; i < 16; i++)
						{
							data[i] = binReader->ReadByte();
							f_count++;
					
							if(f_count==f_length) //The end of file
								break;
					
						}
							InvCipher(data);

				     
						if(f_count==f_length)//The remainder of file's bytes
						{
							if(i!=15)
								i++;
							else
							{
								for(i = 0; i < 16; i++)
								binWriter->Write(data[i]);
								i=0;
							}
							break;
						}
						for(i = 0; i < 16; i++)
							binWriter->Write(data[i]);
					
					}
				  }
				  catch (Exception^ e)
				  {
						if(dynamic_cast<FileNotFoundException^>(e))										
							Windows::Forms::MessageBox::Show("Error : Can't Find Image File", "Error");		
						else
							Windows::Forms::MessageBox::Show("Error : Read Image File Fail", "Error");
				  }
				}

			
					binReader->Close();
					fs->Close();
					binWriter->Close();	
					Windows::Forms::MessageBox::Show("                Done!\n"
						                            +"The size of remainder="+i+"bytes");

				
		
		 }
private: System::Void de_code_check_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
		 {
			 int i;
			 if(this->de_code_check->Checked ==true)
				 for(i=0;i<16;i++)
					this->key_dec_value[i]->Enabled= true;
			 else
				  for(i=0;i<16;i++)
					this->key_dec_value[i]->Enabled= false;

		 }
private: System::Void par_check_CheckedChanged(System::Object^  sender, System::EventArgs^  e) 
		 {
			 if(this->par_check->Checked ==true)
				this->Start_B->Enabled= true;
			 else
				this->Start_B->Enabled= false;

		 }
};
}

